<footer style="background:#111; color:white; padding:20px; text-align:center; margin-top:50px;">
    © 2025 CRISTAL – Innovation · Impact · Excellence
</footer>

<script src="assets/js/script.js"></script>
</body>
</html>