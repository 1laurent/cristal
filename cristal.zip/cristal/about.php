<?php include 'includes/header.php'; ?>

<section class="page-header">
    <h1>À propos du CRISTAL</h1>
</section>

<section class="content">
    <p>
        Le CRISTAL est un collectif étudiant créé en 2016, dédié à la formation, 
        l'engagement, l’innovation et l’excellence...
    </p>
</section>

<?php include 'includes/footer.php'; ?>